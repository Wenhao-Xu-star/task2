import numpy as np
from PIL import Image
import math
import operator
import os
import time
import base64
import random
# from secret import flag

def load_chinanago():
    data = []
    p = Image.open('./chinanago.png').convert('L')
    p = np.array(p).reshape(-1)
    p = np.append(p,1)
    data.append(p)
    return np.array(data)

def load_sakana():
    data = []
    p = Image.open('./sakana.png').convert('L')
    p = np.array(p).reshape(-1)
    p = np.append(p,0)
    data.append(p)
    return np.array(data)

def load_test(pic):
    data = []
    p = Image.open(pic).convert('L')
    p = np.array(p).reshape(-1)
    p = np.append(p,1)
    data.append(p)
    return np.array(data)

def euclideanDistance(instance1, instance2, length):
    distance = 0
    for x in range(length):
        distance += pow((instance1[x] - instance2[x]), 2)
    return math.sqrt(distance)

def getNeighbors(trainingSet, testInstance, k):
    distances = []
    length = len(testInstance) - 1
    for x in range(len(trainingSet)):
        dist = euclideanDistance(testInstance, trainingSet[x], length)
        distances.append((trainingSet[x], dist))
    distances.sort(key=operator.itemgetter(1))
    neighbors = []
    for x in range(k):
        neighbors.append(distances[x][0])
        return neighbors

def getResponse(neighbors):
    classVotes = {}
    for x in range(len(neighbors)):
        response = neighbors[x][-1]
        if response in classVotes:
            classVotes[response] += 1
        else:
            classVotes[response] = 1
    sortedVotes = sorted(classVotes.items(), key=operator.itemgetter(1), reverse=True)
    return sortedVotes[0][0]

def getAccuracy(testSet, predictions):
    correct = 0
    for x in range(len(testSet)):
        if testSet[x][-1] == predictions[x]:
            correct += 1
    return (correct / float(len(testSet))) * 100.0

def check(pic):
    source_p = Image.open('chinanago.png').convert('L')
    try:
        c_p = Image.open(pic).convert('L')
    except:
        print("Please upload right picture.")
        exit()
    diff_pixel = 0
    a, b = source_p.size
    if c_p.size[0] != a and c_p.size[1] != b:
        print("Please upload right picture size("+str(a)+','+str(b)+')')
        exit()
    for y in range(b):
        for x in range(a):
            diff_pixel += abs(source_p.getpixel((x, y)) - c_p.getpixel((x, y)))
    return diff_pixel

def transfer(pic_name):
    '''
        This function could help you submit your result.
        It's not related to the task.
    '''
    h = base64.b64encode(open(pic_name, 'rb').read())
    print(h.decode())
    return h.decode()

def main():
    # print('Give me your sa~ka~na~ picture\'s base64(Preferably in png format)')
    # pic = input('>')
    pic = transfer('sa~ka~na~.png')
    try:
        pic = base64.b64decode(pic)
    except:
        exit()
    salt = str(random.getrandbits(15))
    pic_name = 'tmp_'+salt+'.png'
    tmp_pic = open(pic_name,'wb')
    tmp_pic.write(pic)
    tmp_pic.close()
    '''
            I change 'check(pic_name) >= 250000' to 'check(pic_name) >= 260000'
    '''
    if check(pic_name) >= 260000:
        print('Hacker!')
        os.remove(pic_name)
        exit(0)
    sakana = load_sakana()
    cinanago = load_chinanago()
    k = 1
    trainingSet = np.append(sakana, cinanago).reshape(2, 10001)
    testSet = load_test(pic_name)
    neighbors = getNeighbors(trainingSet, testSet[0], k)
    result = getResponse(neighbors)
    if repr(result) == '0':
        print('Ohhhhh!! It\'s SA~KA~NA~!')
        # I assign the value, because it cannot import name 'flag' from 'secret'
        flag = 0
        print(flag)
        os.remove(pic_name)
        exit(0)
    else:
        print('No. I want SA~KA~NA~!')
        os.remove(pic_name)
        exit(0)

if __name__=='__main__':
    main()