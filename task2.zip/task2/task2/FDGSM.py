import numpy as np
from PIL import Image

def Distance_Gradient( X, Y):
    DG = (Y-X)/np.sqrt(np.sum(((Y-X)**2)))
    return DG

def FDGSM_attack(image, epsilon, DG):
    sign_DG = np.sign(DG)
    # Generate adversarial samples
    perturb_image = image + epsilon*sign_DG
    # Crop, set the pixel value range to 0-255
    perturb_image = np.clip(perturb_image, 0, 255)
    return perturb_image

def load_chinanago():
    data = []
    p = Image.open('./chinanago.png').convert('L')
    p = np.array(p).reshape(-1)
    p = np.append(p,1)
    data.append(p)
    return np.array(data)

def load_sakana():
    data = []
    p = Image.open('./sakana.png').convert('L')
    p = np.array(p).reshape(-1)
    p = np.append(p,0)
    data.append(p)
    return np.array(data)

def make_adversary_sample():
    sakana = load_sakana()
    chinanago = load_chinanago()
    DG = Distance_Gradient(chinanago, sakana)
    epsilon = 0.5
    epochs = 185
    perturb_image = FDGSM_attack(chinanago, epsilon, DG)
    # Imitate the PGD algorithm for several small step iterations to find the optimal DG direction
    for i in range(epochs):
        DG = Distance_Gradient(perturb_image, sakana)
        perturb_image = FDGSM_attack(perturb_image, epsilon, DG)
    perturb_image = np.delete(perturb_image, -1, axis=1)
    perturb_image = perturb_image.reshape(-1,100)
    adv_pic=Image.fromarray(np.uint8(perturb_image))
    adv_pic.show()
    adv_pic.save('sa~ka~na~.png')

if __name__=='__main__':
    make_adversary_sample()